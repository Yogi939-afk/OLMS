import { Wishlist } from './wishlist';

describe('Wishlist', () => {
  it('should create an instance', () => {
    expect(new Wishlist()).toBeTruthy();
  });
});
