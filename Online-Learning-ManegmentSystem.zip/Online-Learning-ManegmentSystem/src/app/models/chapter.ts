export class Chapter 
{
    coursename : string  = '';
    chapter1name : string = '';
    chapter1id : string = '';
    chapter2name : string = '';
    chapter2id : string = '';
    chapter3name : string = '';
    chapter3id : string = '';
    chapter4name : string = '';
    chapter4id : string = '';
    chapter5name : string = '';
    chapter5id : string = '';
    chapter6name : string = '';
    chapter6id : string = '';
    chapter7name : string = '';
    chapter7id : string = '';
    chapter8name : string = '';
    chapter8id : string = '';

    constructor() {}
}
