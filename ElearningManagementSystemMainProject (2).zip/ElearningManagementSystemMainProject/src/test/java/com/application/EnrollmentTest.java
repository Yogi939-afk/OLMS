package com.application;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.application.model.Enrollment;
import com.application.services.EnrollmentService;

class EnrollmentTest {

//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}

	    
		@Autowired 
		private EnrollmentService enrollmentService;
		static Enrollment enrollment;
		@BeforeAll
		static void setUpBeforeClass() throws Exception {
			enrollment=new Enrollment();
			enrollment.setCoursename("Spring Security");
			enrollment.setCourseid("3456");
			enrollment.setEnrolleddate("6-10-2023");
			enrollment.setEnrolledusername("Ashika");
			enrollment.setEnrolleduserid("2227");
			enrollment.setEnrolledusertype("Student");
			enrollment.setInstructorname("Pavitra Nagral");
			enrollment.setInstructorinstitution("EduBridge Learning School");
			enrollment.setEnrolledcount("24");
			enrollment.setYoutubeurl("https://www.youtube.com/watch?v=cjCxPa6_ar0");
			enrollment.setWebsiteurl("https://www.youtube.com/watch?v=cjCxPa6_ar0");
			enrollment.setCoursetype("YouTube");
			enrollment.setSkilllevel("Basic");
			enrollment.setLanguage("English");
			enrollment.setDescription("Introduction of Course");
			
			
		}


		@AfterAll
		static void tearDownAfterClass() throws Exception {
		}

		@BeforeEach
		void setUp() throws Exception {
		}

		@AfterEach
		void tearDown() throws Exception {
		}
	    @Disabled
		@Test
		void test() {
			assertNotNull(enrollmentService.saveEnrollment(enrollment));
			
		}


	}


